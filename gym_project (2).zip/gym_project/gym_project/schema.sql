CREATE TABLE Customer (
    CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,
    FirstName TEXT,
    LastName TEXT,
    DateOfBirth DATE,
    Gender TEXT,
    JoinDate DATE
);

CREATE TABLE Trainer (
    TrainerID INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT,
    Specialty TEXT,
    Phone TEXT,
    HireDate DATE
);

CREATE TABLE Membership (
    MembershipID INTEGER PRIMARY KEY AUTOINCREMENT,
    CustomerID INTEGER,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

CREATE TABLE Payment (
    PaymentID INTEGER PRIMARY KEY AUTOINCREMENT,
    CustomerID INTEGER,
    Date DATE,
    Amount REAL,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

CREATE TABLE TrainingHistory (
    HistoryID INTEGER PRIMARY KEY AUTOINCREMENT,
    CustomerID INTEGER,
    TrainerID INTEGER,
    Date DATE,
    Duration INTEGER,
    Notes TEXT,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (TrainerID) REFERENCES Trainer(TrainerID)
);

CREATE TABLE Equipment (
    EquipmentID INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT,
    Status TEXT
);
