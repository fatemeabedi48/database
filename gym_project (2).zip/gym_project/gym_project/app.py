from flask import Flask, render_template, request, redirect, url_for, send_file
import sqlite3
import io

app = Flask(__name__)

# 📌 گرفتن اعضا (با جستجو و اطلاعات مربی و برنامه)
def get_customers(search=""):
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    if search:
        c.execute("""
            SELECT Customer.*, Trainer.Name AS TrainerName, TrainingHistory.Notes AS Program
            FROM Customer
            LEFT JOIN TrainingHistory ON Customer.CustomerID = TrainingHistory.CustomerID
            LEFT JOIN Trainer ON TrainingHistory.TrainerID = Trainer.TrainerID
            WHERE Customer.FirstName LIKE ? OR Customer.LastName LIKE ?
        """, (f"%{search}%", f"%{search}%"))
    else:
        c.execute("""
            SELECT Customer.*, Trainer.Name AS TrainerName, TrainingHistory.Notes AS Program
            FROM Customer
            LEFT JOIN TrainingHistory ON Customer.CustomerID = TrainingHistory.CustomerID
            LEFT JOIN Trainer ON TrainingHistory.TrainerID = Trainer.TrainerID
        """)
    rows = c.fetchall()
    conn.close()
    return rows

# 📌 گرفتن پرداخت‌ها
def get_payments():
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("""
        SELECT Payment.PaymentID,
               Customer.FirstName || ' ' || Customer.LastName AS FullName,
               Payment.Date,
               Payment.Amount
        FROM Payment
        JOIN Customer ON Payment.CustomerID = Customer.CustomerID
    """)
    rows = c.fetchall()
    conn.close()
    return rows

# 📌 گرفتن عضویت‌های منقضی‌شده
def get_expired_memberships():
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("""
        SELECT Customer.FirstName, Customer.LastName
        FROM Membership
        JOIN Customer ON Membership.CustomerID = Customer.CustomerID
        WHERE EndDate < DATE('now')
    """)
    result = c.fetchall()
    conn.close()
    return result

# 📌 گرفتن اطلاعات یک عضو
def get_customer_by_id(customer_id):
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("SELECT * FROM Customer WHERE CustomerID = ?", (customer_id,))
    customer = c.fetchone()
    conn.close()
    return customer

# 📌 دانلود برنامه ورزشی
@app.route("/download_program/<int:customer_id>")
def download_program(customer_id):
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("""
        SELECT Customer.FirstName, Customer.LastName, TrainingHistory.Notes
        FROM Customer
        LEFT JOIN TrainingHistory ON Customer.CustomerID = TrainingHistory.CustomerID
        WHERE Customer.CustomerID = ?
    """, (customer_id,))
    result = c.fetchone()
    conn.close()

    if not result or not result[2]:
        return "برنامه ورزشی برای این مشتری وجود ندارد!", 404

    # تولید فایل متنی
    program_content = f"""
    برنامه ورزشی برای {result[0]} {result[1]}
    -----------------------------------
    {result[2]}
    """
    file = io.BytesIO(program_content.encode('utf-8'))
    file.seek(0)

    return send_file(
        file,
        as_attachment=True,
        download_name=f"program_{customer_id}.txt",
        mimetype='text/plain'
    )

# 📌 صفحه اصلی
@app.route("/")
def home():
    search = request.args.get("search", "").strip()
    customers = get_customers(search)
    expired_members = get_expired_memberships()
    return render_template("home.html", customers=customers, search=search, expired_members=expired_members)

# 📌 افزودن عضو جدید
@app.route("/add", methods=["GET", "POST"])
def add_customer():
    if request.method == "POST":
        data = (
            request.form["fname"],
            request.form["lname"],
            request.form["dob"],
            request.form["gender"],
            request.form["join_date"]
        )
        conn = sqlite3.connect('gym.db')
        c = conn.cursor()
        c.execute("""
            INSERT INTO Customer (FirstName, LastName, DateOfBirth, Gender, JoinDate)
            VALUES (?, ?, ?, ?, ?)
        """, data)
        conn.commit()
        conn.close()
        return redirect(url_for('home'))
    return render_template("add.html")

# 📌 ویرایش عضو
@app.route("/edit/<int:customer_id>", methods=["GET", "POST"])
def edit_customer(customer_id):
    customer = get_customer_by_id(customer_id)
    if not customer:
        return "مشتری یافت نشد!", 404

    if request.method == "POST":
        data = (
            request.form["fname"],
            request.form["lname"],
            request.form["dob"],
            request.form["gender"],
            request.form["join_date"],
            customer_id
        )
        conn = sqlite3.connect('gym.db')
        c = conn.cursor()
        c.execute("""
            UPDATE Customer
            SET FirstName = ?, LastName = ?, DateOfBirth = ?, Gender = ?, JoinDate = ?
            WHERE CustomerID = ?
        """, data)
        conn.commit()
        conn.close()
        return redirect(url_for('home'))

    return render_template("edit.html", customer=customer)

# 📌 حذف عضو
@app.route("/delete/<int:customer_id>", methods=["POST"])
def delete_customer(customer_id):
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("DELETE FROM Customer WHERE CustomerID = ?", (customer_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('home'))

# 📌 پرداخت‌ها
@app.route("/payments")
def show_payments():
    payments = get_payments()
    return render_template("payments.html", payments=payments)

@app.route("/add-payment", methods=["GET", "POST"])
def add_payment():
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("SELECT CustomerID, FirstName || ' ' || LastName FROM Customer")
    customers = c.fetchall()

    if request.method == "POST":
        data = (
            request.form["customer_id"],
            request.form["date"],
            request.form["amount"]
        )
        c.execute("INSERT INTO Payment (CustomerID, Date, Amount) VALUES (?, ?, ?)", data)
        conn.commit()
        conn.close()
        return redirect(url_for('show_payments'))

    conn.close()
    return render_template("add_payment.html", customers=customers)

# 📌 اعضایی که تمرین می‌کنند ولی پرداخت ندارند
@app.route("/query9")
def query9():
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("""
        SELECT DISTINCT Customer.FirstName, Customer.LastName
        FROM Customer
        JOIN TrainingHistory ON Customer.CustomerID = TrainingHistory.CustomerID
        WHERE Customer.CustomerID NOT IN (SELECT CustomerID FROM Payment)
    """)
    result = c.fetchall()
    conn.close()
    return render_template("query9.html", result=result)

# 📌 گزارش‌ها
@app.route("/reports")
def reports():
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("SELECT SUM(Amount) FROM Payment")
    total_income = c.fetchone()[0] or 0

    c.execute("SELECT SUM(Amount) FROM Payment WHERE Date LIKE '2025-06-%'")
    june_income = c.fetchone()[0] or 0

    c.execute("""
        SELECT Trainer.Name, COUNT(DISTINCT TrainingHistory.CustomerID) AS Clients
        FROM Trainer
        JOIN TrainingHistory ON Trainer.TrainerID = TrainingHistory.TrainerID
        GROUP BY Trainer.TrainerID
        ORDER BY Clients DESC
        LIMIT 1
    """)
    top_trainer = c.fetchone() or ("نداریم", 0)

    conn.close()
    return render_template("reports.html",
                           total_income=total_income,
                           june_income=june_income,
                           top_trainer=top_trainer)

# 📌 مربیان
@app.route("/trainers")
def trainers():
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("SELECT TrainerID, Name, Specialty FROM Trainer")
    trainers = c.fetchall()
    conn.close()
    return render_template("trainers.html", trainers=trainers)

@app.route("/trainer/<int:trainer_id>")
def trainer_profile(trainer_id):
    conn = sqlite3.connect('gym.db')
    c = conn.cursor()
    c.execute("SELECT Name, Specialty, Phone, HireDate FROM Trainer WHERE TrainerID = ?", (trainer_id,))
    trainer = c.fetchone()

    c.execute("""
        SELECT DISTINCT Customer.FirstName, Customer.LastName
        FROM TrainingHistory
        JOIN Customer ON TrainingHistory.CustomerID = Customer.CustomerID
        WHERE TrainerID = ?
    """, (trainer_id,))
    clients = c.fetchall()

    c.execute("SELECT Date, Duration, Notes FROM TrainingHistory WHERE TrainerID = ?", (trainer_id,))
    trainings = c.fetchall()

    conn.close()
    return render_template("trainer_profile.html", trainer=trainer, clients=clients, trainings=trainings)

# 📌 اجرا
if __name__ == "__main__":
    app.run(debug=True)