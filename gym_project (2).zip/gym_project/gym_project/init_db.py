import sqlite3

with open('schema.sql') as f:
    sql = f.read()

conn = sqlite3.connect('gym.db')
c = conn.cursor()
c.executescript(sql)
conn.commit()
conn.close()

print("Database created successfully.")
