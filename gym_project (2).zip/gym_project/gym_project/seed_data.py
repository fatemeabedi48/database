import sqlite3

conn = sqlite3.connect('gym.db')
c = conn.cursor()
# اضافه کردن مربی به برنامه 
c.execute("INSERT INTO TrainingHistory (CustomerID, TrainerID, Date, Duration, Notes) VALUES (?, ?, ?, ?, ?)",
          (2, 1, "2024-06-08", 45, "Cardio and core"))

# اضافه‌کردن اعضا
c.execute("INSERT INTO Customer (FirstName, LastName, DateOfBirth, Gender, JoinDate) VALUES (?, ?, ?, ?, ?)",
          ("Ali", "Rezaei", "1995-05-20", "Male", "2024-01-01"))

c.execute("INSERT INTO Customer (FirstName, LastName, DateOfBirth, Gender, JoinDate) VALUES (?, ?, ?, ?, ?)",
          ("Sara", "Mohammadi", "1998-10-15", "Female", "2024-03-10"))

# اضافه‌کردن مربی
c.execute("INSERT INTO Trainer (Name, Specialty, Phone, HireDate) VALUES (?, ?, ?, ?)",
          ("Mehdi Karimi", "Weightlifting", "09120000000", "2023-06-01"))

# عضویت
c.execute("INSERT INTO Membership (CustomerID, EndDate) VALUES (?, ?)", (1, "2025-01-01"))

# پرداخت‌ها
c.execute("INSERT INTO Payment (CustomerID, Date, Amount) VALUES (?, ?, ?)", (1, "2024-06-01", 500000))
c.execute("INSERT INTO Payment (CustomerID, Date, Amount) VALUES (?, ?, ?)", (2, "2024-06-05", 600000))

# سوابق تمرین
c.execute("INSERT INTO TrainingHistory (CustomerID, TrainerID, Date, Duration, Notes) VALUES (?, ?, ?, ?, ?)",
          (1, 1, "2024-06-07", 60, "Upper body"))

# تجهیزات
c.execute("INSERT INTO Equipment (Name, Status) VALUES (?, ?)", ("Treadmill", "Working"))
c.execute("INSERT INTO Equipment (Name, Status) VALUES (?, ?)", ("Dumbbell Set", "Under Repair"))

conn.commit()
conn.close()

print("Test data inserted successfully.")
